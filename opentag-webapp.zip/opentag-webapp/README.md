# OpenTag Tracker webapp

Egyszerű, statikus webapp a Seeed Studio XIAO nRF52840 `OpenTag-Test` BLE prototípushoz.

## Mit tud

- Web Bluetooth eszközválasztás `OpenTag-Test` név alapján
- GATT kapcsolat állapotának kijelzése
- BLE advertising események figyelése, ha a böngésző támogatja
- RSSI megjelenítés
- RSSI-alapú, kalibrálható távolságbecslés
- A számítógép/telefon saját GPS-helyzetének megjelenítése OpenStreetMap térképen
- A trackerhez tartozó távolság bizonytalansági köre a saját pozíció körül
- Részletes eseménynapló

## Fontos korlát

A jelenlegi Arduino sketch csak BLE advertisinget konfigurál:

- név: `OpenTag-Test`
- TX power: `4`
- advertising interval: 160 / 1600 (a Bluefruit API szerint 100 ms / 1 s)
- nincs saját GATT service/characteristic
- nincs GPS a XIAO-n

Ezért a webapp nem állít elő hamis GPS-koordinátát a trackerhez. A térkép a felhasználó saját helyzetét mutatja, a tracker pedig közelségi/RSSI adatként jelenik meg.

A távolságbecslés képlete:

`d = 10 ^ ((RSSI_1m - RSSI) / (10*n))`

ahol `RSSI_1m` egy 1 méteren mért kalibrációs érték, `n` pedig a környezetre jellemző becslési tényező.

## Indítás

A Web Bluetooth secure contextot igényel. Fejlesztéshez a legegyszerűbb:

```bash
python -m http.server 8000
```

Majd Chromium-alapú böngészőben nyisd meg:

`http://localhost:8000`

Mobiltelefonon általában HTTPS-en érdemes publikálni, például GitHub Pages vagy más statikus tárhely segítségével.

## Következő fejlesztési lépés

A következő firmware-verzióba érdemes saját BLE GATT service-t és characteristic-eket felvenni (például tracker ID, battery és konfiguráció), hogy a webapp ne csak a beacon közelségét lássa, hanem az eszközt ténylegesen is kezelni tudja.
